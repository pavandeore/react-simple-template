import React from 'react';
import HeaderComponent from './components/headerComponent';
import MainComponent from './components/mainComponent';
import FooterComponent from './components/footerComponent';

function App(){
    return (
        <div>
            <HeaderComponent />
            <MainComponent />
            <FooterComponent />        
        </div>
    )   
}
export default App;