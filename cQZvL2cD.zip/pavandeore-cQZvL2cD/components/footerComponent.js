import React from 'react';

function FooterComponent(){
    return (
        <div className="footer-style">
        <h3>This is Footer &copy;</h3>
        <ul><li>Mail to : <a href="mailto:pavandeore90@gmail.com">pavandeore90@gmail.com</a></li>
        <li>Visit: <a href="https://pavandeore.github.io">Port<b>Folio</b></a></li></ul>
        </div>
    )   
}
export default FooterComponent;