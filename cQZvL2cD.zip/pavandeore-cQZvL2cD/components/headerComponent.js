import React from 'react';

function HeaderComponent(){
    return (
        <div>
        <nav>
        <h2><span style={{color:'blue'}}>Some</span>Site.com</h2>
        <ul>
        <li>Home</li>
        <li>Services</li>
        <li>Contact</li>
        </ul>
        </nav>
        </div>
    )   
}
export default HeaderComponent;