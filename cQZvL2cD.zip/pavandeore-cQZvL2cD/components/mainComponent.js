import React from 'react';

function MainComponent(){
    return (
        <div>
        <div className='content-1'>
            <div>This some content This some content This some content This some content This some content This some content This some content This some content This some content This some content This some content </div>
            <div>This some content This some content This some content This some content This some content This some content This some content This some content This some content This some content This some content </div>
        </div><br/>
        <div className='content-2'>
            <img src="https://cdn-5ce4a003f911c80f50818892.closte.com/wp-content/uploads/2016/05/css-gradient-text.png" />
        </div><br/>
         <div className='content-3'>
            <div>This some content This some content This some content This some content This some content This some content This some content This some content This some content This some content This some content </div>
            <div>This some content This some content This some content This some content This some content This some content This some content This some content This some content This some content This some content </div>
        </div>
        </div>
    )   
}
export default MainComponent;